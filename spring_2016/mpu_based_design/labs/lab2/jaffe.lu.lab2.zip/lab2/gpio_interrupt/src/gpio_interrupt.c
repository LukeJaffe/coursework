/**
 *@file gpio_interrupt.c
 *
 *@brief
 *  - Gpio input example using interrupts. The leds corresponding to the push buttons are turned on/off
 * 
 *
 * LastChange:
 * $Id: gpio_interrupt.c 934 2016-02-01 14:22:16Z zhangjinghan $
 *
 *******************************************************************************/


#include "zedboard_freertos.h"
#include "gpio_interrupt.h"


/* user GPIO Interrupt handler */
static void gpio_intrHandler(void *pRef);

/* setup interrupt connection */
static int gpio_setupInts(void);

/* Bits where LEDs are located */
//#define BANK2_LED_BITS

/* bits for inputs */
//#define BANK2_INT_BITS



/* GPIO Task */
static void gpio_task( void *pvParameters )
{

	/* setup interrupts
	 * Note: needs to be called in task context as GIC is initialized
	 * upon starting of multi tasking.
	 */
	gpio_setupInts();

	// suspend this task. All activities are in interrupts.
	vTaskSuspend(NULL);
}


/* Connect interrupt handler */
static int gpio_setupInts(void) {

	// pointer to driver structure
	XScuGic *pGIC;
	// get pointer to GIC (already initialized at OS startup
	pGIC = prvGetInterruptControllerInstance();
	// connect own interrupt handler to GIC handler
	XScuGic_Connect(pGIC, GPIO_INTERRUPT_ID,
	(Xil_ExceptionHandler) gpio_intrHandler,(void *) NULL);
	// Enable interrupt at GIC
	XScuGic_Enable(pGIC, GPIO_INTERRUPT_ID);
	/* Enable IRQ at core (should be enabled anyway)*/
	Xil_ExceptionEnableMask(XIL_EXCEPTION_IRQ);

	/* Enable IRQ in processor core  */

	return XST_SUCCESS;
}

/**
 * Function that is called when an interrupt happens
 *
 * Parameters:
 *
 * @return void
 */
static void gpio_intrHandler(void *pRef) {
	// read interrupt status
	u32 int_assert = (*(volatile u32 *)GPIO_INT_STAT_2) & ~(*(volatile u32 *)GPIO_INT_MASK_2);

	// clear interrupts
	(*(volatile u32 *)GPIO_INT_STAT_2) = int_assert;

	// implement output logic
	(*(volatile u32 *)GPIO_DATA_2) = ((*(volatile u32 *)GPIO_DATA_2)>>16) & 0x1F;
}


/**
 * Initialize the GPIO
 *
 * Parameters:
 *
 * @return void
 */
void gpio_init(void) {

    /* OutEnable for LEDs  */
	*(volatile u32 *)GPIO_DIRM_2 = 0x000000FF;
    *(volatile u32 *)GPIO_OEN_2 =  0x000000FF;

    /* disable interrupts before configuring new ints */
    *(volatile u32 *)GPIO_INT_DIS_2 = 0xFFFFFFFF;


    *(volatile u32 *)GPIO_INT_TYPE_2 = 0x001FFF00;
    *(volatile u32 *)GPIO_INT_POLARITY_2 = 0x001FFF00;
    *(volatile u32 *)GPIO_INT_ANY_2 = 0x001FFF00;

    /* enable input bits */
    *(volatile u32 *)GPIO_INT_EN_2 = 0x001FFF00;
}

/**
 *
 *
 * Parameters:
 *
 * @return void
 */
void gpio_start(void)
{
	xTaskCreate( gpio_task, ( signed char * ) "HW", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1 , NULL );
}



