/**
 *@file main.c
 *
 *@brief Testing code for External I/O abstract
 *
 * Target:   Zedboard-Zynq-7000    
 *
 * @author    Siddharth Velu
 * @date      07/08/2010
 *
 *
 *******************************************************************************/

#include <stdio.h>
#include "gpio_ttc.h"
#include "zedboard_freertos.h"

int main( void )
{
	pwm_init();

    /* Start the GPIO task */
    pwm_start();

    vTaskStartScheduler();

    // This line shouldn't be reached.
    return 0;
}
