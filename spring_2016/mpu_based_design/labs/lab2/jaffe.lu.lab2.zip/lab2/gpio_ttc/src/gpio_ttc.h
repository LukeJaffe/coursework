/**
 *@file gpio_ttc.h
 *
 *@brief
 *	- GPIO pwm code
 *
 * Target:   Zedboard
 *
 *@author    Rohan Kangralkar, ECE, Northeastern University
 *@date      07/08/2010
 *
 * LastChange:
 * $Id$
 *
 *******************************************************************************/
#ifndef GPIO_TTC_H_
#define GPIO_TTC_H_
/** gpio_init
 *
 * Initialization of PORTFIO. This PORT is used as GPIO.
 * The output and input direction can be set using the MACROS
 *
 * Parameters:
 *
 * @return void
 */
void gpio_init(void);

/** gpio_init
 *
 * The main command loop. Write all the control commands in this function
 *
 * Parameters:
 *
 * @return void
 */
void gpio_run(void);


void pwm_init(void);
void pwm_start(void);

/************************** Constant Definitions *****************************/

/*
 * The following constants map to the XPAR parameters created in the
 * xparameters.h file. They are only defined here such that a user can easily
 * change all the needed parameters in one place.
 */

// /** Base address for GPIO peripheral*/
#define GPIO_BASE 0xe000a000

/* DIRM: Direction Mode. This controls whether the I/O pin is
acting as an input or an output. Since the input logic is
always enabled, this effectively enables/disables the output driver.
When DIRM[x]==0, the output driver is disabled. */
#define GPIO_DIRM_2 (GPIO_BASE + 0x284)

/* OEN: Output Enable. When the I/O is configured as an output,
this controls whether the output is enabled or not.
When the output is disabled, the pin is 3-stated.
When OEN[x]==0, the output driver is disabled. */
#define GPIO_OEN_2 (GPIO_BASE + 0x288)

// Definitions of Triple Timer Counter MMR, Refer Pg 1769 in Zynq TRM.

// /** Base address for TTC0 peripherals*/
#define TTC0_T0_BASE 0xF8001000

#define CLK_VAL (TTC0_T0_BASE + 0x00000018)


/******** Set Clock Control Definition ********************/
#define SET_CLK_CNTRL_VAL (TTC0_T0_BASE + 0x00000000U)  /**< Clock Control Register*/


/******** Set Counter Control Definition ********************/
#define SET_CNT_CNTRL_VAL (TTC0_T0_BASE + 0x0000000C)  /**< Counter Control Register*/


/*If interval is enabled, this is the maximum value
that the counter will count up to or down from.
*/
#define SET_INTERVAL_VAL (TTC0_T0_BASE + 0x00000024)  /**< Interval Count Value */

/*When a counter has the same value as is stored in
one of its match registers and match mode is
enabled, a match interrupt is generated. Each
counter has three match registers.
*/
#define SET_MATCH_0_VAL	(TTC0_T0_BASE + 0x00000030)  /**< Match 1 value */
#define SET_MATCH_1_VAL	(TTC0_T0_BASE + 0x0000003C)  /**< Match 2 value */
#define SET_MATCH_2_VAL	(TTC0_T0_BASE + 0x00000048)  /**< Match 3 value */

#endif /* GPIO_PWM_H_ */


