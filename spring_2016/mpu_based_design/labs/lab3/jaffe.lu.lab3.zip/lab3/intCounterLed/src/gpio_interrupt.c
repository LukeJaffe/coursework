/**
 *@file gpio_interrupt.c
 *
 *@brief
 *  - Introduction lab for the TLL6527 platform
 *  - Gpio input example using interrupts.The leds corresponding to the push buttons are turned on/off
 * 
 *
 * Compiler: VDSP++     Output format: VDSP++ "*.dxe"
 *
 *@author    Rohan Kangralkar, ECE, Northeastern University
 *@date      01/16/2010
 *
 * LastChange:
 * $Id: gpio_interrupt.c 928 2016-01-30 19:38:14Z velu.s $
 *
 *******************************************************************************/


#include "zedboard_freertos.h"
#include "gpio_interrupt.h"

/* user GPIO Interrupt handler */
static void gpio_intrHandler(void *pRef);

/* setup interrupt connection */
static int gpio_setupInts(void);

/* Define QueueHandle */
QueueHandle_t gCountUpdateQ;

// LED pattern array
unsigned int patternArray[4];

static int counter;

unsigned char shift(unsigned char val, int mag)
{
	if (mag < 0)
		return val >> abs(mag);
	else
		return val << mag;
}

void getPWMChangeBitPattern(unsigned int value, unsigned int patternArray[4])
{
	int s = (value / 4) - 1;
	unsigned int p = 2 * (value % 4);
	unsigned int d0 = shift(((0b11111101 >> p) & 0b11), s);
	unsigned int d1 = shift(((0b10110101 >> p) & 0b11), s);
	unsigned int d2 = shift(((0b10000101 >> p) & 0b11), s);
	unsigned int d3 = shift(((0b00000001 >> p) & 0b11), s);
	// assume all LEDs are off at the beginning of a period
	unsigned int m1 = (~(d1 ^ d0) << 16) & 0xFFFF0000;
	unsigned int m2 = (~(d2 ^ d1) << 16) & 0xFFFF0000;
	unsigned int m3 = (~(d3 ^ d2) << 16) & 0xFFFF0000;
	patternArray[0] = d0;
	patternArray[1] = m1 | d1;
	patternArray[2] = m2 | d2;
	patternArray[3] = m3 | d3;
}

static void led_task( void *pvParameters )
{
	for (;;)
	{
		int i;
		for (i = 0; i < 4; i++)
		{
			vTaskDelay(1);
			(*(volatile u32 *)MASK_DATA_2_LSW) = patternArray[i];
		}
	}
}

/* GPIO Task */
static void gpio_task( void *pvParameters )
{

	/* setup interrupts
	 * Note: needs to be called in task context as GIC is initialized
	 * upon starting of multi tasking.
	 */
	gpio_setupInts();
	
	
	/* Create a queue capable of containing 10 unsigned long values. */
	gCountUpdateQ = xQueueCreate( 10, sizeof(int));

	for(;;)
	{
		u32 value;
		/* Receive the counter value from Queue */
		if( xQueueReceive( gCountUpdateQ, &value, 0) )
		{
			vTaskDelay(2);
			u32 gpio_data = (*(volatile u32 *)GPIO_DATA_2);
			if ((gpio_data & (0x01<<20)) & (value & (0x01<<20)))
			{
				counter++;
				printf("%d\n", counter);
				getPWMChangeBitPattern(counter, patternArray);
			}
			if ((gpio_data & (0x01<<18)) & (value & (0x01<<18)))
			{
				counter--;
				printf("%d\n", counter);
				getPWMChangeBitPattern(counter, patternArray);
			}
			*(volatile u32 *)GPIO_INT_EN_2 = (0x01<<18 | 0x01<<20);
		}
	}


	// suspend this task. All activities are in interrupts.
	vTaskSuspend(NULL);
}


static int gpio_setupInts(void) {

	// pointer to driver structure
	XScuGic *pGIC;
	// get pointer to GIC (already initialized at OS startup
	pGIC = prvGetInterruptControllerInstance();
	// connect own interrupt handler to GIC handler
	XScuGic_Connect(pGIC, GPIO_INTERRUPT_ID,
	(Xil_ExceptionHandler) gpio_intrHandler,(void *) NULL);
	// Enable interrupt at GIC
	XScuGic_Enable(pGIC, GPIO_INTERRUPT_ID);
	/* Enable IRQ at core (should be enabled anyway)*/
	Xil_ExceptionEnableMask(XIL_EXCEPTION_IRQ);


	/* Enable IRQ in processor core  */

	return XST_SUCCESS;
}

/**
 * Function that is called when an interrupt happens
 *
 * Parameters:
 *
 * @return void
 */
static void gpio_intrHandler(void *pRef)
{
	// read interrupt status
	u32 int_assert = (*(volatile u32 *)GPIO_INT_STAT_2) & ~(*(volatile u32 *)GPIO_INT_MASK_2);

	// clear interrupts
	(*(volatile u32 *)GPIO_INT_STAT_2) = int_assert;

	xQueueSendFromISR( gCountUpdateQ,( void * ) &int_assert, NULL);

	*(volatile u32 *)GPIO_INT_DIS_2 = 0xFFFFFFFF;
}


/**
 * Initialize the GPIO
 *
 * Parameters:
 *
 * @return void
 */
void gpio_init(void) {

    /* OutEnable for LEDs which is top 8 bits need to be set to 1 */
	*(volatile u32 *)GPIO_DIRM_2 = 0x000000FF;
    *(volatile u32 *)GPIO_OEN_2 =  0x000000FF;

    /* disable interrupts before configuring new ints */
    *(volatile u32 *)GPIO_INT_DIS_2 = 0xFFFFFFFF;

    *(volatile u32 *)GPIO_INT_TYPE_2 = (0x01<<18 | 0x01<<20);
    *(volatile u32 *)GPIO_INT_POLARITY_2 = (0x01<<18 | 0x01<<20);
    *(volatile u32 *)GPIO_INT_ANY_2 = (0x01<<18 | 0x01<<20);

    /* enable input bits */
    *(volatile u32 *)GPIO_INT_EN_2 = (0x01<<18 | 0x01<<20);
}

/**
 *
 *
 * Parameters:
 *
 * @return void
 */
void gpio_start(void)
{
	xTaskCreate( gpio_task, ( signed char * ) "HW", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1 , NULL );
	xTaskCreate( led_task, ( signed char * ) "HW", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1 , NULL );
}



