/**
 *@file gpio_interrupt.c
 *
 *@brief
 *  - Introduction lab for the TLL6527 platform
 *  - Gpio input example using interrupts.The leds corresponding to the push buttons are turned on/off
 * 
 *
 * Compiler: VDSP++     Output format: VDSP++ "*.dxe"
 *
 *@author    Rohan Kangralkar, ECE, Northeastern University
 *@date      01/16/2010
 *
 * LastChange:
 * $Id: gpio_interrupt.c 928 2016-01-30 19:38:14Z velu.s $
 *
 *******************************************************************************/


#include "zedboard_freertos.h"
#include "gpio_interrupt.h"

/* user GPIO Interrupt handler */
static void gpio_intrHandler(void *pRef);

/* setup interrupt connection */
static int gpio_setupInts(void);

/* Define QueueHandle */
QueueHandle_t gCountUpdateQ;

/* GPIO Task */
static void gpio_task( void *pvParameters )
{

	/* setup interrupts
	 * Note: needs to be called in task context as GIC is initialized
	 * upon starting of multi tasking.
	 */
	gpio_setupInts();
	
	
	/* Create a queue capable of containing 10 unsigned long values. */
	gCountUpdateQ = xQueueCreate( 10, sizeof(int));

	for(;;)
	{
		/* Receive the counter value from Queue */
		int value;
		if( xQueueReceive( gCountUpdateQ, &value, 1000) )
		{
			printf("Value is %d \n", value);
		}
	}


	// suspend this task. All activities are in interrupts.
	vTaskSuspend(NULL);
}


static int gpio_setupInts(void) {

	// pointer to driver structure
	XScuGic *pGIC;
	// get pointer to GIC (already initialized at OS startup
	pGIC = prvGetInterruptControllerInstance();
	// connect own interrupt handler to GIC handler
	XScuGic_Connect(pGIC, GPIO_INTERRUPT_ID,
	(Xil_ExceptionHandler) gpio_intrHandler,(void *) NULL);
	// Enable interrupt at GIC
	XScuGic_Enable(pGIC, GPIO_INTERRUPT_ID);
	/* Enable IRQ at core (should be enabled anyway)*/
	Xil_ExceptionEnableMask(XIL_EXCEPTION_IRQ);


	/* Enable IRQ in processor core  */

	return XST_SUCCESS;
}

/**
 * Function that is called when an interrupt happens
 *
 * Parameters:
 *
 * @return void
 */
static void gpio_intrHandler(void *pRef)
{
	/* Define the static counter */
	static int counter = 0;

	// read interrupt status
	u32 int_assert = (*(volatile u32 *)GPIO_INT_STAT_2) & ~(*(volatile u32 *)GPIO_INT_MASK_2);

	// clear interrupts
	(*(volatile u32 *)GPIO_INT_STAT_2) = int_assert;


	/* counter manipulation */
	/* Send the counter value to Queue */
	if (int_assert & (0x01<<20))
	{
		counter++;
	}
	if (int_assert & (0x01<<18))
	{
		counter--;
	}
	xQueueSendFromISR( gCountUpdateQ,( void * ) &counter, NULL);
}


/**
 * Initialize the GPIO
 *
 * Parameters:
 *
 * @return void
 */
void gpio_init(void) {

    /* OutEnable for LEDs which is top 8 bits need to be set to 1 */
    *(volatile u32 *)GPIO_DIRM_2 = 0x00000000;
    *(volatile u32 *)GPIO_OEN_2 =  0x00000000;

    /* disable interrupts before configuring new ints */
    *(volatile u32 *)GPIO_INT_DIS_2 = 0xFFFFFFFF;

    *(volatile u32 *)GPIO_INT_TYPE_2 = (0x01<<18 | 0x01<<20);
    *(volatile u32 *)GPIO_INT_POLARITY_2 = (0x01<<18 | 0x01<<20);
    *(volatile u32 *)GPIO_INT_ANY_2 = 0x00000000;

    /* enable input bits */
    *(volatile u32 *)GPIO_INT_EN_2 = (0x01<<18 | 0x01<<20);
}

/**
 *
 *
 * Parameters:
 *
 * @return void
 */
void gpio_start(void)
{
	xTaskCreate( gpio_task, ( signed char * ) "HW", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1 , NULL );
}



