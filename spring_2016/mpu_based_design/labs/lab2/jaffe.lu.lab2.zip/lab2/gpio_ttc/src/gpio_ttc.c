
#include "zedboard_freertos.h"
#include "gpio_ttc.h"
#include "gpio_interrupt.h"

#define DUTY_CYCLE_MAX	(4161)
#define DUTY_CYCLE_MIN	(1041)
#define DUTY_CYCLE_NEUTRAL	(2602)
#define DUTY_CYCLE_INC	(208)

void gpio_init(void);
static int gpio_setupInts(void);
static void gpio_intrHandler(void *pRef);

void pwm_reset();
void pwm_shift(unsigned int);

static u32 Duty_Cycle;

void gpio_init(void) {

    /* OutEnable for LEDs  */
	*(volatile u32 *)GPIO_DIRM_2 = 0x000000FF;
    *(volatile u32 *)GPIO_OEN_2 =  0x000000FF;

    /* disable interrupts before configuring new ints */
    *(volatile u32 *)GPIO_INT_DIS_2 = 0xFFFFFFFF;


    *(volatile u32 *)GPIO_INT_TYPE_2 = (0x01<<17 | 0x01<<18 | 0x01<<20);
    *(volatile u32 *)GPIO_INT_POLARITY_2 = (0x01<<17 | 0x01<<18 | 0x01<<20);
    *(volatile u32 *)GPIO_INT_ANY_2 = 0x00000000;

    /* enable input bits */
    *(volatile u32 *)GPIO_INT_EN_2 = (0x01<<17 | 0x01<<18 | 0x01<<20);
}

/* Connect interrupt handler */
static int gpio_setupInts(void) {

	// pointer to driver structure
	XScuGic *pGIC;
	// get pointer to GIC (already initialized at OS startup
	pGIC = prvGetInterruptControllerInstance();
	// connect own interrupt handler to GIC handler
	XScuGic_Connect(pGIC, GPIO_INTERRUPT_ID,
	(Xil_ExceptionHandler) gpio_intrHandler,(void *) NULL);
	// Enable interrupt at GIC
	XScuGic_Enable(pGIC, GPIO_INTERRUPT_ID);
	/* Enable IRQ at core (should be enabled anyway)*/
	Xil_ExceptionEnableMask(XIL_EXCEPTION_IRQ);

	/* Enable IRQ in processor core  */

	return XST_SUCCESS;
}

static void gpio_intrHandler(void *pRef) {
	// read interrupt status
	u32 int_assert = (*(volatile u32 *)GPIO_INT_STAT_2) & ~(*(volatile u32 *)GPIO_INT_MASK_2);

	// clear interrupts
	(*(volatile u32 *)GPIO_INT_STAT_2) = int_assert;

	if (int_assert & (0x01<<20))
	{
		pwm_shift(1);
	}
	if (int_assert & (0x01<<18))
	{
		pwm_shift(0);
	}
	if (int_assert & (0x01<<17))
	{
		pwm_reset();
	}
}

static void pwm_task( void *pvParameters )
{
	gpio_init();
	gpio_setupInts();

	/* nothing to be done, suspend task */
	vTaskSuspend(NULL);
}


void pwm_init(void)
{
	u32 ClockCntl, CounterCntl ,Period;

	//Set Clock Control 7bits, Enable Prescaler(Bit0) and give the Prescaler Value(Bit4:0)
	ClockCntl =  0x0B;
	//0 0 0101 1
	*((volatile u32*)(SET_CLK_CNTRL_VAL)) = ClockCntl;

	/* Set Counter Control 7bits, Wave_pol(Bit6), Wave_en(Bit5), RST(Bit4), Match(Bit3), DEC(Bit2), INT(Bit1), DIS(Bit0) */
	CounterCntl = 0x4A;
	//1 0 0 1 0 1 0
	*((volatile u32*)(SET_CNT_CNTRL_VAL)) = CounterCntl;

	// Set 20ms Period count number
	Period = 34688;
	*((volatile u32*)(SET_INTERVAL_VAL)) = Period;

	// Set 7.5% Duty Cycle count number
	Duty_Cycle = 2602;
	*((volatile u32*)(SET_MATCH_0_VAL)) = Duty_Cycle;
}

void pwm_shift(unsigned int dir)
{
	if (dir && Duty_Cycle < DUTY_CYCLE_MAX)
	{
		Duty_Cycle += DUTY_CYCLE_INC;
		*((volatile u32*)(SET_MATCH_0_VAL)) = Duty_Cycle;
		(*(volatile u32 *)GPIO_DATA_2) = 0x00000000;
	}
	else if (dir && Duty_Cycle >= DUTY_CYCLE_MAX)
	{
		(*(volatile u32 *)GPIO_DATA_2) = (0x0C);
	}
	else if (!dir && Duty_Cycle > DUTY_CYCLE_MIN)
	{
		Duty_Cycle -= DUTY_CYCLE_INC;
		*((volatile u32*)(SET_MATCH_0_VAL)) = Duty_Cycle;
		(*(volatile u32 *)GPIO_DATA_2) = 0x00000000;
	}
	else if (!dir && Duty_Cycle <= DUTY_CYCLE_MIN)
	{
		(*(volatile u32 *)GPIO_DATA_2) = (0x03);
	}
}

void pwm_reset()
{
	*((volatile u32*)(SET_MATCH_0_VAL)) = DUTY_CYCLE_NEUTRAL;
	Duty_Cycle = DUTY_CYCLE_NEUTRAL;
	(*(volatile u32 *)GPIO_DATA_2) = 0x00000000;
}

void pwm_start(void)
{
	//Create a task. This task can be removed if there isn't a need to run any tasks.
	xTaskCreate( pwm_task, ( signed char * ) "HW", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1 , NULL );
}

